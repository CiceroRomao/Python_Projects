--> Componentes:
Nome: Cícero Romão Ribeiro Pereira Filho / Matricula: 411674
Nome: Gabriel Silveira Trentini / Matricula: 404497

--> Observações:
-Projeto a ser Avaliado:
	O projeto final totalmente funcional é o "main.py" em python.

-Adicionais:
	O envio do projeto C foi feito somente para mostrar oq conseguimos realizar em C. Não sendo o alvo principal da avaliação.

	O projeto em C foi feito originalmente com intuito de ser o main porém devido a um erro na hora de realziar o 
	strcpy ou a copia usando um for/while, decidimos passar o projeto para python. 
	
	No projeto C ele realiza a checagem de uma linha dada de entrada e afirma se aquele axioma está correto ou não, 
	não funcionando em alguns casos especificos. Como o A2 onde p = a, q = (a>a) e r = a.

	A função de recebimento de entrada como arquivo(text.txt) e a função referente a o MP só foram desenvolvidas no projeto em python.

	Obs: as entradas devem ser dadas com ";", no final no arquivo.

	
	